#include <iostream>
using namespace std;

int main() {
    //Using the for loop write a program that outputs the numbers
    //12,14,16,18,20,22,24,26,28 
    for(int n =12;n<=28;n+=2){
        cout<<n<<endl;
    }
    return 0;
}